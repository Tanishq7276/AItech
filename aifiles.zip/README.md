# 🧠 ToolsAI Launcher — 60+ Free AI Tools in One Place

> All major AI tools in one beautiful hub — ChatGPT, Claude, Gemini, DeepSeek, Canva, Adobe Firefly, CapCut, Perplexity, Gamma and 50+ more

**Live Demo:** https://YOUR-USERNAME.github.io/toolsai-launcher

---

## ✨ What's Inside

### 🤖 AI Chatbots (12+)
ChatGPT · Claude AI · Google Gemini · DeepSeek · Perplexity · Grok · Microsoft Copilot · Meta AI · Mistral · Poe · HuggingChat

### ⚡ Built-in AI Tools (14 — works with API key)
AI Chat · Content Writer · Code Generator · Prompt Maker · Resume Builder · Grammar Fixer · Translator · Quiz Maker · Business Plan · Email Writer · Caption Maker · Story Writer · SQL Generator

### 🎨 Image Tools (12+)
Midjourney · Adobe Firefly · DALL-E 3 · Stable Diffusion · Ideogram · Canva · Remove.bg · Photopea · Leonardo AI · Runway ML

### 🎬 Video Tools
CapCut · Sora · Pika AI · Kling AI · InVideo

### 🖥️ Design & Office
Gamma · Notion AI · Excel Online · Google Sheets · Google Docs · Figma

### 💻 Code Tools
GitHub Copilot · Replit · v0.dev · Cursor AI · Codeium · StackBlitz

### 🎵 Audio & Music
ElevenLabs · Suno AI · Udio · Voicemaker

---

## 🚀 How to Use

### Option 1 — Open Directly
1. Download `index.html`
2. Open in Chrome browser
3. For built-in AI tools: enter your API key → Connect
4. For external tools: click any card → opens in new tab

### Option 2 — GitHub Pages (Live Website)
1. Fork this repo
2. Go to **Settings → Pages**
3. Source: `main` branch → Save
4. Live at: `https://YOUR-USERNAME.github.io/toolsai-launcher`

---

## 🔑 API Key (for Built-in Tools only)
- Get free key at **console.anthropic.com**
- Enter in the top bar → Connect
- External tools (ChatGPT, Canva etc.) work without any key

---

## 📁 Project Structure
```
toolsai-launcher/
├── index.html    ← Complete app (single file)
└── README.md     ← This file
```

---

## ⚠️ Honest Note
External tools open their **official free tier** — Canva Pro, Excel paid features etc. are NOT cracked or bypassed. This is a launcher that helps you quickly access all free tiers in one place.

---

*Built with ❤️ — Single file, zero dependencies, works everywhere*
